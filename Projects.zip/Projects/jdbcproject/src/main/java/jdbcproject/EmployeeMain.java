package jdbcproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeMain {
	
	public static void main(String[] args) {
		
		try {
			//1
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_db", "root", "root");
			
			Scanner scan = new Scanner(System.in);
			System.out.println("Employee operations:");
			System.out.println("-------------------------------");
			System.out.println("Enter '1' to add Employee, '2' to update Employee, '3' to delete Employee, '4' to view all Employee, \n "
					+ "'5' to display Employee info by id, '6' to sort data by id, '7' to sort by name, '8' to print all employee names, '9' to add emp using callableSt || '0' to Exit:");
			int choice = scan.nextInt();
			do {
				switch(choice) {
				case 1:
					//EmployeeOperationsObj.addEmployee( con);
					EmployeeOperation.addEmployee( con);

					break;
				case 2:
					//EmployeeOperationsObj.updateEmployee(con);
					EmployeeOperation.updateEmployee(con);

					break;
				case 3:
					//EmployeeOperationsObj.deleteEmployee(con);
					EmployeeOperation.deleteEmployee(con);

					break;
				case 4:
					/*
					ArrayList<Employee> empList= new ArrayList<Employee>();
					empList = (ArrayList<Employee>) EmployeeOperationsObj.allEmployee(con, empList);
					if(empList.isEmpty()) {
						System.out.println("No records found.");
					}else {
						System.out.println("Employee List: ");
						System.out.println("------------------------");
						for(Employee e : empList) {
							System.out.println(e);
						}
					}
					*/
					
					 EmployeeOperation.allEmployee(con);
					
					break;
				
				case 5:
					/*
					Employee emp = new Employee();
					emp = EmployeeOperationsObj.getEmployeeById(con);
					System.out.println(emp);
					*/
					 EmployeeOperation.getEmployeeById(con);
					break;
					
				case 6:
					EmployeeOperation.sortById(con);
					break;
					
				case 7:
					EmployeeOperation.sortByName(con);
					break;
					
				case 8:
					EmployeeOperation.getName(con);
					break;
					
				case 9:
					EmployeeOperation.callableAddEmp(con);
					break;
					
				default:
						System.out.println("Invalid input.");
				}
				
				System.out.println();
				System.out.println("Enter '1' to add Employee, '2' to update Employee, '3' to delete Employee, '4' to view all Employee, \n "
						+ "'5' to display Employee info by id, '6' to sort data by id, '7' to sort by name, '8' to print all employee names, '9' to add emp using callableSt || '0' to Exit:");
				choice = scan.nextInt();
			
			}while(choice != 0);
			con.close();
			
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		System.out.println("--------------------------");
		System.out.println("End of program");
	}

}
