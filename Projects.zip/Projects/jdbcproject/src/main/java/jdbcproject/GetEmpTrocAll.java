package jdbcproject;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class GetEmpTrocAll {

	public static void main(String[] args) {
		try {			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db", "root", "root");
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter employee id: ");
			int id = scan.nextInt();
			CallableStatement cst = con.prepareCall("{call getEmployee_troc(?,?,?,?)}");
			
			cst.setInt(1, id);
			
			cst.registerOutParameter(2,Types.VARCHAR);
			cst.registerOutParameter(3,Types.VARCHAR);
			cst.registerOutParameter(4,Types.BIGINT);


			cst.execute();
			
			if(cst.getString(2) != null) {
				
				System.out.println("Emp_name:  " + cst.getString(2) + "\n Emp_department: " + cst.getString(3) + "\n Emp_phoneNum: " + cst.getLong(4) );
				
			}
			else {
				System.out.println("no records found");

			}
			
			
			
		
			
			con.close();
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		
		
		
	}
	}

}
