package jdbcproject;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AddProcedureCall {
	
	public static void main(String[] args) {
		
		try {			
		
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db", "root", "root");
			
			CallableStatement cst = con.prepareCall("{call new_db.addemployee_troc(?,?,?,?)}");
			
			cst.setInt(1, 75);
			cst.setString(2, "Jerry");
			cst.setString(3, "Biology");
			cst.setLong(4, 45678);
			cst.execute();
			
			System.out.println("record inserted successfully.");
			
			con.close();
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		
		
		
	}
	
	}
}
