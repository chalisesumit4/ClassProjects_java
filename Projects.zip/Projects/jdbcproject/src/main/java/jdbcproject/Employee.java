package jdbcproject;

public class Employee {
	
	private byte id;
	private String name;
	private String department;
	private long phoneNum;
	
	public byte getId() {
		return id;
	}
	public void setId(byte id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public long getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(long phoneNum) {
		this.phoneNum = phoneNum;
	}
	@Override
	public String toString() {
		return "Employee Id: " + id +"\n" +
				"Name: " + name + "\n" +
			     "Department: " + department + "\n"+ 
				"Phone Number: " + phoneNum + "\n";
	}
	
	
	
	

}
