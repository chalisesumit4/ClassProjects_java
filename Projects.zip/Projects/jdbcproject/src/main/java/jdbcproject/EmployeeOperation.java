package jdbcproject;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class EmployeeOperation {
	
	public static int addEmployee( Connection con) throws SQLException{
		
		Scanner sc = new Scanner(System.in);		
		System.out.println("Enter employee id: ");
		byte id = sc.nextByte();
		System.out.println("Enter employee name: ");
		String eName = sc.next();
		System.out.println("Enter department: ");
		String department = sc.next();
		System.out.println("Enter phone number: ");
		long phoneNum = sc.nextLong();
		
		PreparedStatement ps = con.prepareStatement("insert into emp_table(emp_id, emp_name, emp_department, emp_phoneNum) values(?,?,?,?)");
		ps.setInt(1, id);
		ps.setString(2, eName);
		ps.setString(3, department);
		ps.setLong(4, phoneNum);
		
		int result = ps.executeUpdate();
		System.out.println("Employee added successfully.");
		return result;
	}
	
	public static int updateEmployee(Connection con) throws SQLException {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id to update: ");
		int empId = sc.nextInt();
		System.out.println("Enter employee name: ");
		String empName = sc.next();
		System.out.println("Enter department: ");
		String department = sc.next();
		System.out.println("Enter phone number: ");
		long phoneNum = sc.nextLong();
		
		PreparedStatement ps = con.prepareStatement("update emp_table set emp_name=?, emp_department=?, emp_phoneNum=? where emp_id="+empId);
		ps.setString(1, empName);
		ps.setString(2, department);
		ps.setLong(3, phoneNum);
		int result = ps.executeUpdate();
		System.out.println("Employee updated successfully.");
		return result;
	}
	
	public static int deleteEmployee(Connection con) throws SQLException{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id to delete from records: ");
		int empId = sc.nextInt();
		PreparedStatement ps = con.prepareStatement("delete from emp_table  where emp_id="+empId);
		int result = ps.executeUpdate();
		System.out.println("Employee deleted successfully.");
		return result;
	}
	
	public static void getEmployeeById(Connection con) throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id: ");
		int empId = sc.nextInt();
		
		PreparedStatement ps = con.prepareStatement("select * from emp_table where emp_id =" + empId);
		ResultSet rs = ps.executeQuery();
		System.out.println("Employee Details: ");
		System.out.println("-------------------------------");
		while(rs.next()) {
			System.out.println("Id: " + rs.getByte(1));
			System.out.println("Name: " + rs.getString(2));
			System.out.println("Department: " + rs.getString(3));
			System.out.println("Phone number: " + rs.getLong(4));
		}
	}
	
	public static void allEmployee(Connection con) throws SQLException {
		
		PreparedStatement ps = con.prepareStatement("select *  from emp_table");
		ResultSet rs = ps.executeQuery();
		System.out.println("Employee Details: ");
		System.out.println("-------------------------------");
		while(rs.next()) {
			System.out.println("Id: " + rs.getByte(1));
			System.out.println("Name: " + rs.getString(2));
			System.out.println("Department: " + rs.getString(3));
			System.out.println("Phone number: " + rs.getLong(4));
			System.out.println();
		}
	}
	
	public static void sortById(Connection con) throws SQLException {
		
		//PreparedStatement ps = con.prepareStatement("select * from emp_table order by emp_id asc");//asc order
		PreparedStatement ps = con.prepareStatement("select * from emp_table order by emp_id desc");//desc order

		ResultSet rs = ps.executeQuery();
		System.out.println("Employee Details: ");
		System.out.println("-------------------------------");
		while(rs.next()) {
			System.out.println("Id: " + rs.getByte(1));
			System.out.println("Name: " + rs.getString(2));
			System.out.println("Department: " + rs.getString(3));
			System.out.println("Phone number: " + rs.getLong(4));
			System.out.println();
		}
	}
	
public static void sortByName(Connection con) throws SQLException {
		
		//PreparedStatement ps = con.prepareStatement("select * from emp_table order by emp_name desc");//desc order
		PreparedStatement ps = con.prepareStatement("select * from emp_table order by emp_name asc");//asc order

		ResultSet rs = ps.executeQuery();
		System.out.println("Employee Details: ");
		System.out.println("-------------------------------");
		while(rs.next()) {
			System.out.println("Id: " + rs.getByte(1));
			System.out.println("Name: " + rs.getString(2));
			System.out.println("Department: " + rs.getString(3));
			System.out.println("Phone number: " + rs.getLong(4));
			System.out.println();
		}
}
		
		//callable statement
		public static void getName(Connection con) throws SQLException {
			
			CallableStatement cs = con.prepareCall("{call getName()}");
			boolean hasName = cs.execute();
			if(hasName) {
				ResultSet rs = cs.getResultSet();
				while(rs.next()) {
					System.out.println(rs.getString("emp_name"));
				}
			}else {
				System.out.println("No record found.");
			}
		}
		
		public static void callableAddEmp(Connection con) throws SQLException {
			
			Scanner sc = new Scanner(System.in);		
			System.out.println("Enter employee id: ");
			byte id = sc.nextByte();
			System.out.println("Enter employee name: ");
			String eName = sc.next();
			System.out.println("Enter department: ");
			String department = sc.next();
			System.out.println("Enter phone number: ");
			long phoneNum = sc.nextLong();		
			CallableStatement cs = con.prepareCall("{call addEmployee(?,?,?,?)}");
			cs.setByte(1, id);
			cs.setString(2, eName);
			cs.setString(3, department);
			cs.setLong(4, phoneNum);
			cs.execute();
			System.out.println("Employee added successfully.");
			System.out.println();
		}
}
