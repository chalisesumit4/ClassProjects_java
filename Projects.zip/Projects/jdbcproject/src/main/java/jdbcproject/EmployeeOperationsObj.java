package jdbcproject;

// employee operations through collection framework and objects


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EmployeeOperationsObj {
	
	public static int addEmployee( Connection con) throws SQLException{
		
		Scanner sc = new Scanner(System.in);
		Employee emp = new Employee();
		
		System.out.println("Enter employee id: ");
		emp.setId(sc.nextByte());
		System.out.println("Enter employee name: ");
		emp.setName(sc.next());
		System.out.println("Enter department: ");
		emp.setDepartment(sc.next());
		System.out.println("Enter phone number: ");
		emp.setPhoneNum(sc.nextLong());
		
		//2
		PreparedStatement ps = con.prepareStatement("insert into emp_table(emp_id, emp_name, emp_department, emp_phoneNum) values(?,?,?,?)");
		ps.setInt(1, emp.getId());
		ps.setString(2, emp.getName());
		ps.setString(3, emp.getDepartment());
		ps.setLong(4, emp.getPhoneNum());
		
		//3
		int result = ps.executeUpdate();
		System.out.println("Employee added successfully.");
		return result;
	}
	
	public static int updateEmployee(Connection con) throws SQLException {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id to update: ");
		int empId = sc.nextInt();
		System.out.println("Enter employee name: ");
		String empName = sc.next();
		System.out.println("Enter department: ");
		String department = sc.next();
		System.out.println("Enter phone number: ");
		long phoneNum = sc.nextLong();
		
		PreparedStatement ps = con.prepareStatement("update emp_table set emp_name=?, emp_department=?, emp_phoneNum=? where emp_id="+empId);
		ps.setString(1, empName);
		ps.setString(2, department);
		ps.setLong(3, phoneNum);
		int result = ps.executeUpdate();
		System.out.println("Employee updated successfully.");
		return result;
		
	}
	
	public static int deleteEmployee(Connection con) throws SQLException{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id to delete from records: ");
		int empId = sc.nextInt();
		PreparedStatement ps = con.prepareStatement("delete from emp_table  where emp_id="+empId);
		int result = ps.executeUpdate();
		System.out.println("Employee deleted successfully.");
		return result;
		
	}
	
	public static Employee getEmployeeById(Connection con) throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id: ");
		int empId = sc.nextInt();
		
		PreparedStatement ps = con.prepareStatement("select * from emp_table where emp_id =" + empId);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			Employee emp = new Employee();
			emp.setId(rs.getByte(1));
			emp.setName(rs.getString(2));
			emp.setDepartment(rs.getString(3));
			emp.setPhoneNum(rs.getLong(4));
			return emp;
		}
		return null;
	}
	
	public static List<Employee> allEmployee(Connection con, ArrayList<Employee> empList) throws SQLException {
		
		PreparedStatement ps = con.prepareStatement("select *  from emp_table");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			Employee emp = new Employee();
			emp.setId(rs.getByte("emp_id"));
			emp.setName(rs.getString("emp_name"));
			emp.setDepartment(rs.getString("emp_department"));
			emp.setPhoneNum(rs.getLong("emp_phoneNum"));
			empList.add(emp);
			
			
		}
		return empList;
	}

}
