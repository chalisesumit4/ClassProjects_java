package jdbcproject;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class CalculateAllowanceFunc {

	public static void main(String[] args) {
		
		try {			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db", "root", "root");
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter employee id: ");
			int id = scan.nextInt();
			System.out.println("Enter percentage: ");
			float percentage = scan.nextFloat();
			CallableStatement cst = con.prepareCall("{ ? = call new_db.calculate_allowance(?,?)}");
			
			cst.setInt(2, id);
			cst.setFloat(3, percentage);
			cst.registerOutParameter(1, Types.FLOAT);
			
		
			cst.execute();
			
			
			if(cst.getFloat(1) != 0.0) {
				
				System.out.println("Allowance :  " + cst.getFloat(1) );
				
			}
			else {
				System.out.println("no records found");

			}
			
			con.close();
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		
		
		
	}
		
		

	}

}
