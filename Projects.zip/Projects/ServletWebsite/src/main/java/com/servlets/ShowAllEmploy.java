package com.servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class ShowAllEmploy
 */
@WebServlet("/ShowAllEmploy")
public class ShowAllEmploy extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	 PreparedStatement pst;

 
    public void init(ServletConfig config) throws ServletException {  
		  try
		  {

			  Class.forName("com.mysql.jdbc.Driver");   
			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db","root", "root");
			  pst=con.prepareStatement("select * from emp_table ");
	  }catch(SQLException | ClassNotFoundException e) {
		  e.printStackTrace();
	  }
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	  // TODO Auto-generated method stub
    	  
    	  response.setContentType("text/html");
    	     PrintWriter pw=response.getWriter();        

    	     try {
    	     ResultSet rs=pst.executeQuery();
    	     ResultSetMetaData md=rs.getMetaData();

    	     String responseText="";  
    	     responseText=responseText.concat("<table align=center border=2 cellspacing=0 width=60% bgcolor=yellow>");

    	       for (int i = 1; i <=md.getColumnCount(); i++) {    //   shows table columns  
    	        responseText=responseText.concat("<th style='background-color:cyan'>"+md.getColumnName(i).toUpperCase()+"</th>");
    	   }       
    	       while(rs.next())               //   display records
    	       {  
    	        responseText=responseText.concat("<tr>"); 
    	        
    	        for (int i = 1; i <=md.getColumnCount(); i++) {
    	         responseText=responseText.concat("<td style='text-align:center'>"+rs.getString(i)+"</td>");
    	      }         
    	        responseText=responseText.concat("</tr>");    
    	     }        
    	       
    	       responseText=responseText.concat("</table>");
    	 
    	     pw.print(responseText);     
    	          
    	     } catch(SQLException ex) {
    	      ex.printStackTrace();
    	     }
    	     
    	     
    	  
    	  
    	 }

    


}
