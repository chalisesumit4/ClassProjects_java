package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/AddEmploy")
public class AddEmploy extends HttpServlet {
		 private static final long serialVersionUID = 1L;
		 /**
		  * @see Servlet#init(ServletConfig)
		  */
		 PreparedStatement pst;
		 public void init(ServletConfig config) throws ServletException {  
		  try
		  {
		  Class.forName("com.mysql.jdbc.Driver");   
		  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db","root", "root");
		  pst=con.prepareStatement("insert into emp_table values(?,?,?,?,?) ");
	  }catch(SQLException | ClassNotFoundException e) {
		  e.printStackTrace();
	  }
		 }
		  
	  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			  
			  response.setContentType("text/html");
			     PrintWriter pw=response.getWriter();        
			     //taking the request from html page    
			     String eid=request.getParameter("eid");    
			     String ename=request.getParameter("ename");    
			     String edepartment=request.getParameter("edepartment");    
			     String ephonenum=request.getParameter("ephonenum");
			     String esalary=request.getParameter("esalary");

			     try { 
			     pst.setInt(1, Integer.parseInt(eid));
			     pst.setString(2, ename);
			     pst.setString(3, edepartment);
			     pst.setLong(4, Long.parseLong(ephonenum));
			     pst.setDouble(5,Double.parseDouble(esalary) );
			     int result=pst.executeUpdate();
			     if(result>0) {
			      pw.print("<body bgcolor=cyan><h2 align=center>record inserted</h2></body>");
			     }
			     }
			    catch(SQLException ex){
			     pw.print("problem occurs during insertion :"+ex.getMessage());
			    }
			    }


}
	 