package com.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/EmailValidation")
public class EmailValidation extends HttpServlet {
 private static final long serialVersionUID = 1L;
 
 private static PreparedStatement pst;
 
 public void init(ServletConfig config) throws ServletException {
  
  try {
   Class.forName("com.mysql.cj.jdbc.Driver");
   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db", "root","root");
   pst = con.prepareStatement("select username from users where email_id=? and password=?");
  }
  catch(SQLException  | ClassNotFoundException ex) {
   ex.printStackTrace();
  }
 }

 public void destroy() {
  // TODO Auto-generated method stub
 }

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  // TODO Auto-generated method stub  
  
  String emailid = request.getParameter("emailid");
  String password = request.getParameter("password");
  response.setContentType("text/html");
  PrintWriter pw = response.getWriter();  
  try {
   pst.setString(1, emailid);
   pst.setString(2, password);
   ResultSet rs = pst.executeQuery();
   if(rs.next()) {    //  if record exists    
    
       // store emailid  into the session object 
    HttpSession session = request.getSession();
    session.setAttribute("email", emailid);
    
    response.sendRedirect("operations.html");
       //pw.print(" welcome "+rs.getString(1));
    
   } else {
    pw.print("Invalid username / password <br><a href=login.html> <h3>Try Again</h3> </a>");
   }
   
  }catch(SQLException  ex) {
   ex.printStackTrace();
  }
 }

}