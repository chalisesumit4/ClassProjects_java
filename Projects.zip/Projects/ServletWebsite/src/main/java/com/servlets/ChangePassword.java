package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class ChangePassword
 */
@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
 private static final long serialVersionUID = 1L;   

 PreparedStatement pst;
 public void init(ServletConfig config) throws ServletException {  
  try
  {
  Class.forName("com.mysql.jdbc.Driver");   
  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db","root", "root");
  pst=con.prepareStatement("update users set password=? where email_id=?");
  }
  catch(ClassNotFoundException | SQLException ex) {
  ex.printStackTrace(); 
  }   
 }
 
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 
  String password=request.getParameter("password");  
  response.setContentType("text/html");
  PrintWriter pw=response.getWriter(); 
  try {
   pst.setString(1, password);
   HttpSession session=request.getSession();
   String email =(String)session.getAttribute("email");   
   pst.setString(2, email);
   int result=pst.executeUpdate();
   if(result>0) {
    pw.print("<body bgcolor=cyan><h2>updated successfully</h2></body>");
   }   
  }
  catch(SQLException ex) {
   ex.printStackTrace();
  }
 }
}