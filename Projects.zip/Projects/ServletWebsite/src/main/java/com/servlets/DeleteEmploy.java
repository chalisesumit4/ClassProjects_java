package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class DeleteEmploy
 */
@WebServlet("/DeleteEmploy")
public class DeleteEmploy extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
		PreparedStatement pst;
	   public void init(ServletConfig config) throws ServletException {  
			  try
			  {

				  Class.forName("com.mysql.jdbc.Driver");   
				  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db","root", "root");
				  pst=con.prepareStatement("delete from emp_table where emp_id = ?");
		  }catch(SQLException | ClassNotFoundException e) {
			  e.printStackTrace();
		  }
	    }


	   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   
	        String eid=request.getParameter("eid");  
	  response.setContentType("text/html");
	  PrintWriter pw=response.getWriter();
	  try {
	  pst.setInt(1, Integer.parseInt(eid));
	 
	  int result=pst.executeUpdate();
	  
	  if(result>0) {
	   pw.print("<h2>Record deleted</h2>");
	  } else {
	   pw.print("<h2> no record exists with "+eid+"</h2>  <a href='operations.html'>  Try Again</a>");
	  }
	  
	  }
	  catch(SQLException ex) {
	   ex.printStackTrace();
	  }

	     
	 
	 }
}
