package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class TestServlets
 */
@WebServlet("/TestServlets")
public class TestServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("in init method");
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in do getMethod");
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		pw.print("<body bgcolor=red></body>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in dopost method");
		
	response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		pw.print("<body bgcolor=green></body>");
	}
	
	public void destroy() {
	
	System.out.println("in destroy method");
	}

}
