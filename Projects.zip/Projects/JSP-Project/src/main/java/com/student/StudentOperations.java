package com.student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class StudentOperations { 
 static PreparedStatement pst1,pst2,pst3,pst4,pst5,pst6,pst7,pst8; 
 static {
  try
  {
   // db configuration 
  Class.forName("com.mysql.jdbc.Driver");   
  Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db","root", "root");
 // Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_","root", "krishna");  
  
  pst1=con1.prepareStatement("select email_id from users where email_id=? and password=?");
  pst2=con1.prepareStatement("insert into student_details values(?,?,?,?)");
  pst3=con1.prepareStatement("select * from student_details");
  pst4=con1.prepareStatement("delete from student_details where sno=?");
  pst5=con1.prepareStatement("select sno from student_details");
  pst6=con1.prepareStatement("select sname,scourse,sfees from student_details where sno=?");
  pst7=con1.prepareStatement("update student_details set sname=?,scourse=?,sfees=? where sno=?");
  pst8=con1.prepareStatement("update users set password=? where emailid=?");
       
  }
  catch(ClassNotFoundException | SQLException ex) {
  ex.printStackTrace(); 
  }   
 }
 
 public static boolean checkEmailAndPaswword(String emailid,String password) {
	  boolean status=false;
	  try {
	   pst1.setString(1, emailid);
	   pst1.setString(2,password);
	   ResultSet rs=pst1.executeQuery();
	   if(rs.next()) { 
	    status=true;
	   }    
	   }
	   catch(SQLException ex) {
	    ex.printStackTrace();
	   }
	  return status;
	 }
 
 public static boolean addStudentDetails(int sid,String sname,String scourse,float sfee) {
	 
	  boolean status=false;
	  try {
	  pst2.setInt(1, sid);
	  pst2.setString(2,sname);
	  pst2.setString(3, scourse);
	  pst2.setFloat(4, sfee);
	  int result=pst2.executeUpdate();
	  if(result>0) {
	   status=true;
	  }
	  }
	  catch(SQLException ex) {
	   ex.printStackTrace();
	  }  
	  return status;
	 }
 
 public static String showStudents() {
	   String responseText="";      
	  try {
	       ResultSet rs=pst3.executeQuery();
	       ResultSetMetaData md=rs.getMetaData();

	       responseText=responseText.concat("<table align=center border=2 cellspacing=0 width=60% bgcolor=yellow>");

	         for (int i = 1; i <=md.getColumnCount(); i++) {    //   shows table columns  
	          responseText=responseText.concat("<th style='background-color:cyan'>"+md.getColumnName(i).toUpperCase()+"</th>");
	     }       
	         while(rs.next())               //   display records
	         {  
	          responseText=responseText.concat("<tr>");           
	          for (int i = 1; i <=md.getColumnCount(); i++) {
	           responseText=responseText.concat("<td style='text-align:center'>"+rs.getString(i)+"</td>");
	        }         
	          responseText=responseText.concat("</tr>");    
	       }
	         responseText=responseText.concat("</table>");
	   
	            
	       } catch(SQLException ex) {
	        ex.printStackTrace();
	       }
	       
	    return responseText;
	 }
	 
	 
	 
 
}